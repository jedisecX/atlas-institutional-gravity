# ATLAS - Institutional Gravity

**ATLAS** builds an evidence-backed relationship graph from a raw list of names.
It normalizes/deduplicates messy OCR-like input and enriches entities using public sources
(UN-related pages, government mission pages, major institutions), then exports a network
map for D3/Sigma/Neo4j/Gephi.

> **Purpose:** structural mapping of publicly documented institutional relationships.  
> **Not** allegations. **Not** guilt-by-association. Every edge is designed to carry a receipt.

## Install

```bash
git clone https://github.com/YOURUSER/atlas-institutional-gravity.git
cd atlas-institutional-gravity
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Usage

1) Put your raw list in `input/names.txt` (ignored by git by default).

2) Build base graph (dedupe):
```bash
python3 scripts/build_network.py
```

3) Enrich with public sources (evidence-backed edges):
```bash
python3 scripts/enrich_web.py
```

4) Render interactive HTML:
```bash
python3 scripts/render_html.py
```
Open `out/graph.html`.

## License
MIT
